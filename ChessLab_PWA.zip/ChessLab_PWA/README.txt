ChessLab PWA 프로토타입

배포/설치:
1. 폴더 안 파일을 HTTPS 정적 호스팅에 업로드 (예: GitHub Pages 또는 Netlify)
2. 갤럭시 Chrome에서 배포된 HTTPS 주소 접속
3. 메뉴(⋮) > 앱 설치 또는 홈 화면에 추가

현재:
- Chess.com 스타일의 어두운 리뷰 화면
- 체스판에서 기물 이동
- 수순 탐색

미완성:
- Chess.com 대국 링크 자동 가져오기
- Stockfish 기반 평가/정확도/최선의 수
- 수별 자연어 해설

현재 ZIP은 실제 완성 APK가 아닌 PWA 소스 프로토타입입니다. PWA는 HTTPS로 배포해야 설치할 수 있습니다.
